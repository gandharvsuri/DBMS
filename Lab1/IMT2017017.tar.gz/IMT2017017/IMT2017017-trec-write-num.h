#ifndef IMT2017017_trec_write_num
#define IMT2017017_trec_write_num

struct student
{
    int rollno;
    char name[30];
    int age;
};

#endif
