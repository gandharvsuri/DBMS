#include<stdio.h>
#include<string.h>
#include<errno.h>
#include<stdlib.h>


// Define the global variable
struct PDS_RepoInfo repo_handle;

int pds_open( char *repo_name )
{
}

int put_rec_by_key( int key, struct Contact *rec )
{
}

int get_rec_by_key( int key, struct Contact *rec )
{
}

int pds_close()
{
}

