insert into item
values
    (101,"engine oil","oil",500,"car","O5",null),
    (102,"MRF tyre","tyre",10000,"car","T4",null),
    (103,"Luminous battery","battery",700,"scooter","B1",null),
    (104,"Brake oil","oil",1500,"car","BO3",null),
    (105,"M3 wax","wax",500,"car","W2",null);

insert into garage
values
    (10001,"Chandigarh","Suri Automobiles",null);

insert into owner
values 
    (1234,"Gandharv","999999999","gs@gmail.com","1234567890"),
    (1345,"Gandharv","999999999","gs@gmail.com","1234567890");

insert into customer 
values 
    (1501,"AB","909090909","ab@ymail.com","qwerty"),
    (1502,"CD","909090909","ab@ymail.com","qwerty"),
    (1503,"XYZ","909090909","ab@ymail.com","qwerty");

insert into bill
values
    (1501,null,1501),
    (1502,null,1502),
    (1503,null,1503);

